// ==UserScript==
// @name          DuckDuckGo Nicer Theme
// @description   Makes duckduckgo nicer looking
// @author        Mateo Grgic & Co.
// @version       0
// @grant         none
// @match         *://duckduckgo.com/*
// @run-at        document-start
// @icon          https://duckduckgo.com/assets/logo_header.alt.v108.svg
// ==/UserScript==

var date = new Date();
date.setTime(date.getTime()+(100*24*60*60*1000));
var expires = "; expires="+date.toGMTString();
document.cookie = "ae=d"+expires+"; path=/";
document.cookie = "bi=1"+expires+"; path=/";
document.cookie = "psb=-1"+expires+"; path=/";
document.cookie = "d=-1"+expires+"; path=/";
document.cookie = "g=p"+expires+"; path=/";
document.cookie = "5=2"+expires+"; path=/";
document.cookie = "bg=-1"+expires+"; path=/";
document.cookie = "be=0"+expires+"; path=/";
document.cookie = "ad=en_GB"+expires+"; path=/";
document.cookie = "z=-1"+expires+"; path=/";
document.cookie = "1=-1"+expires+"; path=/";
document.cookie = "aj=m"+expires+"; path=/";
document.cookie = "ak=-1"+expires+"; path=/";
document.cookie = "ax=-1"+expires+"; path=/";
document.cookie = "au=-1"+expires+"; path=/";
document.cookie = "ao=-1"+expires+"; path=/";
document.cookie = "ap=-1"+expires+"; path=/";
document.cookie = "aq=-1"+expires+"; path=/";
