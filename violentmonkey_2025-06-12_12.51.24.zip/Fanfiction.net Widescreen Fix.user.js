// ==UserScript==
// @name           Fanfiction.net Widescreen Fix
// @author         misc
// @include        *://*.fanfiction.net/*
// @priority       -99999999
// @delay          1300
// ==/UserScript==

document.getElementById("content_wrapper").style.width="95%"
document.getElementById("storytext").parentNode.align="left"