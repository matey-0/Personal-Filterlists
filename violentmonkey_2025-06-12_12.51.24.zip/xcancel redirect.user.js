// ==UserScript==
// @name        xcancel redirect
// @description redirects x & twitter links to xcancel
// @namespace   Violentmonkey Scripts
// @match        *://twitter.com/*
// @match        *://www.twitter.com/*
// @match        *://x.com/*
// @match        *://www.x.com/*
// @version     0.3
// @author      Mateo Grgic & Co.
// ==/UserScript==
window.location.replace("https://xcancel.com" + window.location.pathname + window.location.search);