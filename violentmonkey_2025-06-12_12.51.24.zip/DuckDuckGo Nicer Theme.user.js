// ==UserScript==
// @name          DuckDuckGo Nicer Theme
// @description   Makes duckduckgo nicer looking
// @author        Mateo Grgic & Co.
// @version       0.2
// @grant         none
// @match         *://duckduckgo.com/*
// @icon          https://duckduckgo.com/assets/logo_header.alt.v108.svg
// ==/UserScript==

document.cookie = "ae=d; path=/";
document.cookie = "bi=1; path=/";
document.cookie = "psb=-1; path=/";
document.cookie = "d=-1; path=/";
document.cookie = "g=p; path=/";
document.cookie = "5=2; path=/";
document.cookie = "bg=-1; path=/";
document.cookie = "be=0; path=/";
document.cookie = "ad=en_GB; path=/";
document.cookie = "z=-1; path=/";
document.cookie = "1=-1; path=/";
document.cookie = "aj=m; path=/";
document.cookie = "ak=-1; path=/";
document.cookie = "ax=-1; path=/";
document.cookie = "au=-1; path=/";
document.cookie = "ao=-1; path=/";
document.cookie = "ap=-1; path=/";
document.cookie = "aq=-1; path=/";
