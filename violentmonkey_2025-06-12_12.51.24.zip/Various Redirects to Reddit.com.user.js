// ==UserScript==
// @name        Various Redirects to Reddit.com
// @description redirects redditmedia.com to reddit.com
// @namespace   Violentmonkey Scripts
// @match       *://*redditmedia.com/*
// @match       *://np.reddit.com/*
// @match       *://old.reddit.com/*
// @exclude     *://reddit.com/*
// @version     0.1
// @author      Mateo Grgic & Co.
// ==/UserScript==
window.location.replace("https://reddit.com" + window.location.pathname + window.location.search);