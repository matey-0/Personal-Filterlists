// ==UserScript==
// @name         Kagi Search Token Enabler
// @namespace    https://violentmonkey.github.io/
// @match         *://kagi.com/*
// @version      1.0
// @description  Enables Kagi.com Search token with personalized user settings
// @author       Streampunk (modded by me)
// @icon         https://styles.redditmedia.com/t5_76chzd/styles/communityIcon_2mw0gjk6wus91.png
// @grant        none
// @run-at       document-start
// @license      MIT
// ==/UserScript==

// Set your Kagi Search token here with personalized user settings
   var token = 'PAFAbJkW3Ac.KzoJMO7CNt4xvJ7EYyMjcKbjNj9G6col39k6yBtHps4';

// Set the custom settings value as activated for the script to work properly
   var user_settings = 'activated';

// A Function to Set a Cookie
function setCookie(cName, cValue) {
  const domain = "domain=kagi.com";
  document.cookie = cName + "=" + cValue + ";" + domain + ";";
}

// A Function to Get a Cookie
function getCookie(cName) {
  let Name = cName + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(Name) == 0) {
      return c.substring(Name.length, c.length);
    }
  }
  return "";
}

// A Function that Checks if a Cookie is set
function checkCookie() {
  let user = getCookie("user_settings");
  if (user != "") {
 // Remember to open the console (Press F12)
    console.error("Сookies with custom user settings are set!");
  } else {
 // Apply setCookie
    setCookie('kagi_session', token);
    setCookie('user_settings', user_settings);
    location.reload();
  }
}

// Check if Сookies are set and if not, set a Сookie with a user token
checkCookie();