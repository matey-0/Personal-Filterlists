// ==UserScript==
// @name         Twitter/X Redirect to xcancel
// @version      0.1
// @description  Redirect twitter.com and x.com links
// @author       yodaluca23
// @license      GNU GPLv3
// @match        *://twitter.com/*
// @match        *://www.twitter.com/*
// @match        *://x.com/*
// @match        *://www.x.com/*
// @grant        none
// @downloadURL https://update.greasyfork.org/scripts/499523/TwitterX%20Nitter%20Redirect.user.js
// ==/UserScript==

(function() {
    'use strict';

    // Define the target domain
    const targetDomain = 'xcancel.com';

    // Get the current URL
    let currentURL = window.location.href;

    // Regular expression to match the user profile URLs, with optional additional paths
    const profileURLPattern = /^https?:\/\/(www\.)?(twitter\.com|x\.com)\/[A-Za-z0-9_]+(\/.*)?$/;

    // Check if the current URL matches the user profile pattern
    if (profileURLPattern.test(currentURL)) {
        // Replace twitter.com or x.com with twiiit.com
        let newURL = currentURL.replace(/(twitter\.com|x\.com)/, targetDomain);

        // Redirect to the new URL if it's different from the current URL
        if (newURL !== currentURL) {
            window.location.replace(newURL);
        }
    }
})();