// ==UserScript==
// @name        Redditmedia Redirect to Reddit
// @description redirects redditmedia.com to reddit.com
// @namespace   Violentmonkey Scripts
// @match       *://*redditmedia.com/*
// @version     0.1
// @author      Mateo Grgic & Co.
// @description 2025-04-28, 9:54:48 p.m.
// ==/UserScript==
window.location.replace("https://reddit.com" + window.location.pathname + window.location.search);